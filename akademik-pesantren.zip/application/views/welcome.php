<!-- Content Header (Page header) -->
<center>
<section class="content-header">
  	<div style="vertical-align: middle;">
  		<img style="width: 200px" src="http://pesantren.hidayat.info//assets/images/logo.png" alt="docs-logo"><br><br>
  		<h3 style="font-size:30px; letter-spacing:3px">Selamat Datang di</h3>
  		<div><h1 style="font-size:110px"><b>ALTIS</b>
</h1><h2 style="font-size:30px; letter-spacing:35px;padding-left:32px; line-height:10px;">SYSTEM</h2></div>
  		<h3 style="font-size:35px; letter-spacing:0px;padding-left:15px; line-height:110px;">Akademik TMI Darussalam</h3>
  	</div>	
</section>
</center>