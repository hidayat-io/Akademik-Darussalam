<link href="<?php echo base_url(); ?>/assets/css/error.min.css" rel="stylesheet" type="text/css" />
<div class="row">
    <div class="col-md-12 page-404">
        <div class="number font-red"> 404 </div>
        <div class="details">
            <h3>Oops!</h3>
            <p> Halaman yang Anda cari tidak ditemukan.
                <br/><br/>
                <a href="<?php echo base_url(); ?>"> Kembali ke halaman awal.</a> 
        </div>
    </div>
</div>